#!/bin/bash

# Swaz Data Recovery Labs - Production Deployment Script
# ===================================================================
# This script builds and prepares the application for production deployment
# Usage: ./scripts/deploy-production.sh

set -e  # Exit on any error

echo "🚀 Starting Swaz Data Recovery Labs Production Deployment..."
echo "================================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "package.json" ] || [ ! -f "vite.config.ts" ]; then
    print_error "Please run this script from the project root directory"
    exit 1
fi

print_status "Installing dependencies..."
npm install

print_status "Building production version..."
npm run build

print_status "Verifying production build..."
if [ ! -d "dist" ]; then
    print_error "Production build failed - dist directory not found"
    exit 1
fi

# Check if key files exist in dist
required_files=("dist/index.html" "dist/assets" "dist/sql-wasm.wasm")
for file in "${required_files[@]}"; do
    if [ ! -e "$file" ]; then
        print_error "Required file missing: $file"
        exit 1
    fi
done

print_success "Production build completed successfully!"

# Check if PM2 is available for process management
if command -v pm2 &> /dev/null; then
    print_status "PM2 detected. Setting up process management..."

    # Create PM2 ecosystem file if it doesn't exist
    if [ ! -f "ecosystem.config.js" ]; then
        print_status "Creating PM2 ecosystem configuration..."
        cat > ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'swaz-data-recovery',
    script: 'server/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 8080
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 8080
    }
  }]
};
EOF
        print_success "PM2 ecosystem configuration created"
    fi
else
    print_warning "PM2 not found. Install PM2 for production process management: npm install -g pm2"
fi

print_status "Production deployment preparation complete!"
echo ""
echo "================================================================="
echo "📋 Deployment Instructions:"
echo ""
echo "1. Upload the entire 'dist/' folder to your web server"
echo "2. Configure your web server (Nginx/Apache) to serve static files from 'dist/'"
echo "3. Set environment variables on your server:"
echo "   GEMINI_API_KEY=AIzaSyCbyGCWlBo7FgN2bshNhWi8PHOmK1484qE"
echo ""
echo "4. For WebSocket signaling server (if needed):"
echo "   Start with: node server/index.js"
echo "   Or with PM2: pm2 start ecosystem.config.js"
echo ""
echo "5. Ensure sql-wasm.wasm is accessible at the root level"
echo ""
echo "🌐 Your app will be available at your domain root"
echo "================================================================="

print_success "Production deployment package ready!"
print_success "Total size: $(du -sh dist/ | cut -f1)"
