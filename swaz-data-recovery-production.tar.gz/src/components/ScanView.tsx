import React from 'react';

const ScanView: React.FC = () => null;

export default ScanView;
