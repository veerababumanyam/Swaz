import React from 'react';

const EmailAgentsPage: React.FC = () => {
  return null;
};

export default EmailAgentsPage;
