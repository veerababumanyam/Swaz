import React from 'react';

const PreviewModal: React.FC = () => null;

export default PreviewModal;
