import React from 'react';

const FileItem: React.FC = () => null;

export default FileItem;
